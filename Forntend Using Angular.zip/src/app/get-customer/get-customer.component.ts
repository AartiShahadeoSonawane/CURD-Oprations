import { Component } from '@angular/core';
import { CustomerService } from '../service/customer.service';


@Component({
  selector: 'app-get-customer',
  templateUrl: './get-customer.component.html',
  styleUrls: ['./get-customer.component.css']
})
export class GetCustomerComponent {

    customers: any = [];

  constructor(private customerService:CustomerService){}


  ngOnInit(){
    this.getAllCustomer();
  }

  getAllCustomer(){
    this.customerService.getAllCustomer().subscribe((res)=>{
     console.log(res);
     this.customers = res; 
   },
   (error) => {
     console.error(error);
   })
  }


  deleteCustomer(id: number){
    this.customerService.deleteCustomer(id).subscribe((res)=>{
      console.log(res);
      this.getAllCustomer();
    },
    (error) => {
      console.error(error);
    })
  }

}
