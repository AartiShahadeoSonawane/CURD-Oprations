import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PostCustomerComponent } from './post-customer/post-customer.component';
import { GetCustomerComponent } from './get-customer/get-customer.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';

const routes: Routes = [
{path:'customer' ,component:PostCustomerComponent},
{path:'',component:GetCustomerComponent},
{path:'customer/:id',component:UpdateCustomerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
