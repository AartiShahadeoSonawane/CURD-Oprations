package com.example.Backend.Controller;

import com.example.Backend.Entity.Customer;
import com.example.Backend.Service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @PostMapping("/postCustomer")
    public Customer postCustomer(@RequestBody Customer customer)
    {
       return customerService.postCustomer(customer);
    }


    @GetMapping("/getAllCustomer")
    public List<Customer> getAllCustomer(){
        return customerService.getAllCustomer();
    }

//    @GetMapping("/getCustomer/{id}")
//    public Customer getCustomerById(@PathVariable Long id){
//        Customer customer = customerService.getCustomerById(id);
//
//    }


    @GetMapping("/getCustomer/{id}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable Long id){
        Customer customer = customerService.getCustomerById(id);

        if (customer == null) {
            return ResponseEntity.notFound().build();
        }else {
            return ResponseEntity.ok(customer);
        }
    }

    @PutMapping("/updateCustomer/{id}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable Long id , @RequestBody Customer customer){
        Customer existingCustomer = customerService.getCustomerById(id);

        if (existingCustomer == null)
            return ResponseEntity.notFound().build();

          existingCustomer.setName(customer.getName());
          existingCustomer.setEmail(customer.getEmail());
          existingCustomer.setPhone(customer.getPhone());

          Customer updateCustomer = customerService.updateCustomer(existingCustomer);
          return ResponseEntity.ok(updateCustomer);
    }

    @DeleteMapping("/deleteCustomer/{id}")
    public ResponseEntity<?> deleteCustomer(@PathVariable long id){
       Customer existingCustomer= customerService.getCustomerById(id);

        if (existingCustomer == null)
            return ResponseEntity.notFound().build();

        customerService.deleteCustomer(id);
        return ResponseEntity.ok().build();
    }

}
